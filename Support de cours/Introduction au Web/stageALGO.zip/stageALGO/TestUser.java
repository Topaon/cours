import java.lang.Math;
public class TestUser {
    
    // Méthode main(.)
    public static void main(String[] args) {
        /* 
        // CONSTRUCTEUR PAR DEFAUT (SANS PARAMETRE)
        // Instancier = créer un objet à partir de la classe
        User tintin = new User();

        // Stocker dedans "TINTIN" et 40
        tintin.nom = "TINTIN";
        tintin.age = 40;

        // Afficher le contenu de l'objet : nom, age
        System.out.println("Je suis " + tintin.nom);
        System.out.println("J'ai " + tintin.age + " ans.");

        // Appliquer la méthode getInfos()
        System.out.println(tintin.getInfos());

        String texte = tintin.getInfos();
        System.out.println(texte);
        */


        // CONSTRUCTEUR AVEC 2 PARAMETRES
        // Instancier = créer un objet à partir de la classe
        // User macron = new User("MACRON", 47);
        // System.out.println(macron.getInfos());

        /* 
        // ATTRIBUTS / METHODES STATIQUES
        // Affichons le contenu de l'attribut statique
        System.out.println("Département:" + User.dpt);
        
        // Modifier l'attribut statique
        User.dpt = 78;
        System.out.println("Département:" + User.dpt);

        // Soit un objet...
        User u1 = new User("DUPONT", 60);
        User u2 = new User("PIERRE", 77);
        System.out.println("Département via U1 :" + u1.dpt);
        System.out.println("Département via U2:" + u2.dpt);

        // Changer l'attribut statique VIA l'instance u1
        u1.dpt = 145;
        System.out.println("\n Département:" + u1.dpt);
        System.out.println("Département via U2:" + u2.dpt);
        System.out.println("Département:" + User.dpt);

        // Appliquer la méthode statique
        System.out.println("\n" + User.AfficheDpt());

        // Racine carée de 16 : utilisation statique
        System.out.println("\nRacine de 16:" + Math.sqrt(16));
        */

        /*
        // ENCAPSULATION  AVEC AGE QUI EST PRIVATE
        User m = new User("JEAN", 99);
        System.out.println("Lecture de age: " + m.getAge());   // Lecture
        m.setAge(188);         // Modifier l'age dans l'objet
        System.out.println("Lecture de age: " + m.getAge());   // 188
        */

        // CREER UN OBJET DE TYPE Salarie
        Salarie Haddock = new Salarie("HADDOCK", 85, 7000);
        System.out.println(Haddock.getInfos());
    }
}
