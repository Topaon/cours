public class Salarie extends User {
    
    // Attributs de la classe (= variables d'instance)
    private int salaire;

    // Ajoutons un constructeur
    public Salarie(String nom, int age, int salaire){
        // Appel du constructeur du parent User
        super(nom, age);

        // Attribut spécifique à la classe Salarie
        this.salaire = salaire;
    }

    // Getter (=accesseur) et Setter (=modifieu) pour age qui est private
    public int getSalaire(){
        return this.salaire;
    }
    public void setSalaire(int newsalaire){
        this.salaire = newsalaire;
    }

    // Redéfinir le getInfos()
    public String getInfos(){
        return super.getInfos() + " et je gagne " + this.getSalaire() + "Euros";
    }
}
