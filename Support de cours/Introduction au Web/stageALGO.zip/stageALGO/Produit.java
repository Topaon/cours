/*
        Ecrire un algorithme qui demande deux nombres à l’utilisateur et l’informe 
        ensuite si le produit est négatif ou positif(on inclut cette 
        fois le traitement du cas où le produit peut être nul).


        ALGO Produit
        VAR m, n : Numérique

        DEBUT
            ECRIRE "Donner le 1er nombre"
            LIRE m

            ECRIRE "Donner le 2ème nombre"
            LIRE n

            SI (m > 0 ET n > 0) OU (m <  0 ET n < 0)
                ECRIRE "Produit positif"
            SINON SI m = 0 OU n = 0
                ECRIRE "Produit nul"
            SINON
                ECRIRE "Produit négatif"
            FIN SI
        FIN
 */

import java.util.Scanner;
import java.lang.Math;

public class Produit {
    public static void main(String[] args) {
        
        // Déclarer nos entiers m et n
        int m;
        //int n;

        // Récup d'un 1er nombre
        Scanner sc = new Scanner(System.in);

        // Récup de m
        m = sc.nextInt();
        System.out.println(m);

        // Fermer le scanner
        sc.close();
    }
}
