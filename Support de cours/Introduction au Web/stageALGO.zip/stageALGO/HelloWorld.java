public class HelloWorld{
	
	// Méthode main = qui démarre le programme
	public static void main(String[] args){
		/*
			Super comment
			pr les bavards
		*/
		System.out.println("Bonjour le Monde!");
		System.out.println("Il dit: \"Il est cool\", puis termina!");
		//int Entier = 'a';
		char car = 48;
		System.out.println(car);
	}
}