-- Créer une database
CREATE DATABASE bookstore;

-- Se brancher à la bonne database
USE bookstore;

-- Créer une table : la table, c'est elle qui contient las datas
-- La table sera vide
CREATE TABLE bookstore.Livre(
    id INT(2) PRIMARY KEY AUTO_INCREMENT,
    titre VARCHAR(50),
    auteur VARCHAR(50),
    editeur VARCHAR(50)
);

-- Ajouter 3 livres à notre table
INSERT INTO bookstore.Livre(titre, auteur, editeur)
VALUES('Candide', 'Voltaire', 'Flamarion'), ('Java facile', 'Dupont', 'M2I'), ('Word', 'Bill Gates', 'Microsoft');

-- Modifier le livre de id=3
UPDATE bookstore.Livre
SET auteur = 'Léopold'
WHERE id = 3;

-- Interroger la table et ramener le titre et l'auteur
SELECT titre, auteur FROM bookstore.Livre;