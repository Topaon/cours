public class TestAlgo {
    public static void main(String[] args) {
        
        // Appel de la procédure
        int unAge = 40;
        direAge(unAge);     // unAge est un argument = la data

        // Bonjour Soulef
        direBonjour("Soulef");

        // Bonjour Roland
        direBonjour("Roland");

        // Appel de la fonction carre(.)
        int res = carre(4);
        System.out.println("Carré de 4 est: " + res);
    }

    // Procédure direAge(age)
    public static void direAge(int age){               // age est un paramètre (paramètre formel)
        System.out.println("Votre âge est :" + age);
    }

    public static void direBonjour(String nom){        // nom est un paramètre (paramètre formel)
        System.out.println("Bonjour :" + nom);
    }

    // Créer une fonction carre(nb)
    public static int carre(int nombre){
        int resultat = nombre * nombre;
        return resultat;
    }
}
