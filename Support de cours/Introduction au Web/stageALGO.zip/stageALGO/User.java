public class User {
    
    // Attributs de la classe (= variables d'instance)
    // public int age;
    // private int age;
    // public String nom;
    protected int age;
    protected String nom;

    // Attribut statique
    static int dpt = 77;

    // Ajoutons un constructeur
    // Constructeur = méthode publique de même nom que la 
    // classe
    public User(String nom, int age){

        this.nom = nom;
        this.age = age;
    }

    // Getter (=accesseur) et Setter (=modifieu) pour age qui est private
    public int getAge(){
        return this.age;
    }
    public void setAge(int newage){
        // Valider
        if (newage > 0){
            this.age = newage;
        }
    }

    public String getNom(){
        return this.nom;
    }
    public void setNom(String newname){
        this.nom = newname;
    }


    // Créer la méthode getInfos()  : il s'agit d'une fonction
    public String getInfos(){
        return "Je suis " + this.nom + " et j'ai " + this.age + " ans.";
    }

    // Méthode statique
    // Appelable sans créer d'objet
    public static String AfficheDpt(){
        return "Mon département: " + User.dpt;
    }
}
