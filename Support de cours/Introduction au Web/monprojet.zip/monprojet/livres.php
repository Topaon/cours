<?php

    // Connexion à la DB : API MySQLi
    $conn = mysqli_connect('localhost', 'root', '', 'bookstore');

    // SQL
    $sql = "SELECT id, titre, auteur, editeur FROM livre";

    // Exécutons le sql et obtenons un jeu de données
    $rs = mysqli_query($conn, $sql);

    // Fetch = parcourir le jeu de resultat $rs et récupérer les datas
    while($oLivre = mysqli_fetch_object($rs)){
        // Récup
        $id = $oLivre->id;
        $titre = $oLivre->titre;
        $auteur = $oLivre->auteur;
        $editeur = $oLivre->editeur;

        // Afficher
        print($id . " | " . $titre . " | " . $auteur . " | " . $editeur . "<br>");
    }

    // Fermeture
    mysqli_free_result($rs);
    mysqli_close($conn);



