function coucou(){

    // Créer une variable
    var msg = "Bonjour le Monde entier";

    // On va appeler la fonction alert() pr afficher une boite
    alert(msg);
}