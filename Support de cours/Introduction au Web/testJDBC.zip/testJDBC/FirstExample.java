import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class FirstExample{

    // Nom du driver
    //static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";

    // URL qui pointe vers la database bookstore
    static final String DB_URL = "jdbc:mysql://localhost:3306/bookstore?useUnicode=true&serverTimezone=UTC";

    // Identifiants de connextion
    static final String USER = "root";
    static final String PASS = "";

    // Méthode pour tester JDBC
    public void testJDBC(){

        // Objets : Connection, Statement, ResultSet
        Connection conn = null;
        Statement stmt = null;

        try{
            // Créer conn, avec la méthode statique .getConnection
            System.out.println("Connexion à la base de données....");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            // Créer le statement (on attachera le SQL)
            stmt = conn.createStatement();

            // Requête SQL  + Exécution de la requête (obtenir un ResultSet)
            String sql = "SELECT id, titre, auteur, editeur FROM livre";
            ResultSet rs = stmt.executeQuery(sql);

            // Parcours du ResultSet, et extraction des infos
            while(rs.next()){
                // Récup des infos
                int id = rs.getInt("id");
                String titre = rs.getString("titre");
                String auteur = rs.getString("auteur");
                String editeur = rs.getString("editeur");

                // Affichage des infos
                System.out.println("ID" + id);
                System.out.println("Titre" + titre);
                System.out.println("Auteur" + auteur);
                System.out.println("Editeur" + editeur);
            }

            // Fermer les ressources
            rs.close();
            stmt.close();
            conn.close();
        }
        catch (SQLException se){
            System.out.println(se.getMessage()); // Gestion d'erreur
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
}