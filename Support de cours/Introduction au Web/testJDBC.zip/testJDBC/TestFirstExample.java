public class TestFirstExample {
    public static void main(String[] args) {
        
        // Créer un objet de la classe FirstExample
        FirstExample e = new FirstExample();

        // Exécutons la méthode testJDBC() sur e
        e.testJDBC();
    }
}
